/* ================= ICONS ================= */
const PATHS = {
  menu:'M3 6h18M3 12h18M3 18h18',
  search:'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM21 21l-4.35-4.35',
  home:'M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z',
  flame:'M12 2s5 4.6 5 9.6a5 5 0 0 1-10 0c0-2.1 1-3.7 2.1-5.3.4 1.9 1.4 3 2.9 3.6C11 8 10.4 5 12 2z',
  download:'M12 3v11M7 10l5 5 5-5M4 20h16',
  history:'M12 3a9 9 0 1 0 9 9M12 7v5l3.5 2M21 3v5h-5',
  heart:'M12 21s-8-5.3-8-11a4.6 4.6 0 0 1 8-3.1A4.6 4.6 0 0 1 20 10c0 5.7-8 11-8 11z',
  like:'M7 22V11l4.2-9c1.4 0 2.6 1.2 2.6 2.6L13 9h5.8c1.2 0 2.1 1.1 1.9 2.3l-1.3 8A2 2 0 0 1 17.4 21zM7 22H3.5V11H7',
  share:'M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7M12 3v12M7 8l5-5 5 5',
  play:'M8 5.5v13l11-6.5z',
  pause:'M8 5h3.4v14H8zM12.6 5H16v14h-3.4z',
  vol:'M11 5 6 9H3v6h3l5 4zM15.5 8.5a5 5 0 0 1 0 7M18 6a8.5 8.5 0 0 1 0 12',
  mute:'M11 5 6 9H3v6h3l5 4zM16 9l6 6M22 9l-6 6',
  full:'M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M16 21h3a2 2 0 0 0 2-2v-3M8 21H5a2 2 0 0 1-2-2v-3',
  close:'M18 6 6 18M6 6l12 12',
  trash:'M3 6h18M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2M18.5 6l-1 14a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2l-1-14',
  check:'M20 6 9 17l-5-5',
  moon:'M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z',
  sun:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4',
  music:'M9 18V5l12-2v13M9 18a3 3 0 1 1-6 0 3 3 0 0 1 6 0zM21 16a3 3 0 1 1-6 0 3 3 0 0 1 6 0z',
  film:'M2 4h20v16H2zM7 4v16M17 4v16M2 9h5M2 15h5M17 9h5M17 15h5',
  playC:'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM10 8l6 4-6 4z',
  pauseC:'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM9 8h2.4v8H9zM12.6 8H15v8h-2.4z',
  back:'M15 18l-6-6 6-6',
  info:'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 8h.01M12 11v6',
  gear:'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.9 2.9l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.9-2.9l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.9-2.9l.1.1a1.7 1.7 0 0 0 1.9.3h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.2a1.7 1.7 0 0 0 1 1.5h.1a1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.9 2.9l-.1.1a1.7 1.7 0 0 0-.3 1.9v.1a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.2a1.7 1.7 0 0 0-1.4 1z'
};
function ic(name, s=22, fill=false){
  return `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="${fill?'currentColor':'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${PATHS[name]}"/></svg>`;
}
const icFill = (name,s)=>`<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor"><path d="${PATHS[name]}"/></svg>`;

/* ================= DATA ================= */
const B = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/';
const I = id => `https://storage.googleapis.com/gtv-videos-bucket/sample/images/${id}.jpg`;
const S = {
  bbb:[B+'BigBuckBunny.mp4','BigBuckBunny'], ed:[B+'ElephantsDream.mp4','ElephantsDream'],
  sintel:[B+'Sintel.mp4','Sintel'], tos:[B+'TearsOfSteel.mp4','TearsOfSteel'],
  subaru:[B+'SubaruOutbackOnStreetAndDirt.mp4','SubaruOutbackOnStreetAndDirt'],
  vw:[B+'VolkswagenGTIReview.mp4','VolkswagenGTIReview'],
  grand:[B+'WhatCarCanYouGetForAGrand.mp4','WhatCarCanYouGetForAGrand'],
  bullrun:[B+'WeAreGoingOnBullrun.mp4','WeAreGoingOnBullrun'],
  blazes:[B+'ForBiggerBlazes.mp4','ForBiggerBlazes'], escapes:[B+'ForBiggerEscapes.mp4','ForBiggerEscapes'],
  fun:[B+'ForBiggerFun.mp4','ForBiggerFun'], joy:[B+'ForBiggerJoyrides.mp4','ForBiggerJoyrides'],
  melt:[B+'ForBiggerMeltdowns.mp4','ForBiggerMeltdowns']
};
const V = (id,t,ch,vf,v,d,dur,cat,src)=>({id,t,ch,vf,v,d,dur,cat,src:S[src][0],th:I(S[src][1])});
const VIDEOS = [
  V('v1','Big Buck Bunny — Full Open Movie (4K Remaster)','Blender Studio',1,48219345,'2 years ago','9:56','Movies','bbb'),
  V('v2','Sintel — Award-Winning Fantasy Short Film','Blender Studio',1,21744209,'3 years ago','14:48','Movies','sintel'),
  V('v3','Tears of Steel — Sci-Fi Short Film + VFX','Blender Studio',1,9321587,'1 year ago','12:14','Movies','tos'),
  V('v4','Elephants Dream — The First Open Movie Ever','Blender Studio',1,12803456,'4 years ago','10:53','Animation','ed'),
  V('v5','Subaru Outback — Street & Dirt Full Review','AutoVerse',1,3412765,'8 months ago','9:54','Autos','subaru'),
  V('v6','Volkswagen GTI Review — Still Worth It in 2025?','AutoVerse',1,5210983,'5 months ago','9:53','Autos','vw'),
  V('v7','What Car Can You Actually Get for $1,000?','AutoVerse',1,7823451,'2 months ago','9:52','Autos','grand'),
  V('v8','We Are Going On Bullrun! (Announcement)','DriveLine',0,1204531,'3 weeks ago','0:47','Autos','bullrun'),
  V('v9',"How Sintel's Dragon Was Animated — Breakdown",'Anim School',1,2871049,'7 months ago','14:48','Education','sintel'),
  V('v10','Tears of Steel — VFX Compositing Masterclass','VFX Academy',1,1982455,'1 year ago','12:14','Tech','tos'),
  V('v11',"Big Buck Bunny but it's Weirdly Hilarious 😂",'FrameByFrame',0,6721890,'6 months ago','9:56','Comedy','bbb'),
  V('v12','Elephants Dream — The Hidden Meaning Explained','Reel Decoded',1,3490122,'10 months ago','10:53','Education','ed'),
  V('v13','Every Blender Open Movie, Ranked','Reel Decoded',1,2145780,'2 months ago','12:14','Movies','tos'),
  V('v14','GTI vs The World — Hot Hatch Showdown','DriveLine',0,4412876,'4 months ago','9:53','Autos','vw'),
  V('v15','Budget Build Challenge: Street & Dirt Tests','DriveLine',0,1678234,'3 weeks ago','9:54','Autos','subaru'),
  V('v16','How Open Source Movies Are Actually Made','Anim School',1,1234567,'1 month ago','14:48','Animation','sintel'),
];
const SHORTS = [
  {id:'s1',t:'When the render finally finishes 🔥',ch:'FrameByFrame',v:8213456,src:S.blazes[0],th:I('ForBiggerBlazes')},
  {id:'s2',t:'POV: escaping the deadline ⏰',ch:'Reel Decoded',v:4451203,src:S.escapes[0],th:I('ForBiggerEscapes')},
  {id:'s3',t:'Friday deploy energy 😂',ch:'FrameByFrame',v:12903455,src:S.fun[0],th:I('ForBiggerFun')},
  {id:'s4',t:'Weekend joyride 🚗💨',ch:'AutoVerse',v:3345012,src:S.joy[0],th:I('ForBiggerJoyrides')},
  {id:'s5',t:'Monday meltdown ☕',ch:'LoFi Lab',v:5678231,src:S.melt[0],th:I('ForBiggerMeltdowns')},
];
const CATS = ['All','Movies','Animation','Autos','Music','Tech','Education','Comedy','Trending'];
const COMMENT_POOL = [
  'This is exactly what I was looking for today, thank you!','The quality here is insane 🔥',
  'Watched this 3 times already. Underrated channel.','Who else is watching this at 2am?',
  'Downloading this for my flight tomorrow — the download feature is so handy!',
  'The animation holds up incredibly well even now.','Bro really dropped a masterpiece and said nothing',
  'That transition at the middle was buttery smooth.','Explained better than my entire film course tbh',
  'First! Great upload as always 👏','The soundtrack makes this 10x better.',
  'Notification gang where you at?','Saved to watch later, can\'t wait.'
];

/* ================= STATE ================= */
const $ = s => document.querySelector(s);
const load = (k,d) => { try{ return JSON.parse(localStorage.getItem('vs_'+k)) ?? d; }catch{ return d; } };
const save = (k,v) => { try{ localStorage.setItem('vs_'+k, JSON.stringify(v)); }catch{} };
if(!load('welcomed',false)){ window.location.replace('../welcome.html'); }
const state = {
  page:'home', videoId:null, query:'', category:'All',
  downloads: load('downloads',[]),
  history: load('history',[]),
  liked: load('liked',[]),
  subs: load('subs',[]),
  comments: load('comments',{}),
  cLikes: load('cLikes',[]),
  theme: load('theme','dark'),
};
let engine = null, dlTab='video', modalVideo=null;

/* ================= HELPERS ================= */
const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtN = n => n>=1e6 ? (n/1e6).toFixed(n>=1e7?0:1)+'M' : n>=1e3 ? (n/1e3).toFixed(n>=1e4?0:1)+'K' : n;
const fmtTime = s => { s=Math.max(0,Math.floor(s||0)); const h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;
  return (h?h+':'+String(m).padStart(2,'0'):m)+':'+String(x).padStart(2,'0'); };
const parseDur = d => d.split(':').reduce((a,p)=>a*60+ +p,0);
const fmtSize = mb => mb>=1024 ? (mb/1024).toFixed(2)+' GB' : mb.toFixed(1)+' MB';
const hue = s => [...s].reduce((a,c)=>a+c.charCodeAt(0),0)%360;
const byId = id => VIDEOS.find(v=>v.id===id);
function toast(msg, icon='check', ok=false){
  const t = document.createElement('div');
  t.className = 'toast'+(ok?' ok':'');
  t.innerHTML = ic(icon,20)+`<span>${msg}</span>`;
  $('#toasts').appendChild(t);
  setTimeout(()=>{ t.classList.add('out'); setTimeout(()=>t.remove(),300); }, 2600);
}

/* ================= NAV ================= */
const NAV = [
  ['home','Home','home'],['trending','Trending','flame'],['downloads','Downloads','download'],
  ['sep'],['Library','label'],
  ['history','History','history'],['liked','Liked videos','heart'],
];
function renderNav(){
  $('#sidebar').innerHTML = NAV.map(n=> n[0]==='sep' ? '<div class="nav-sep"></div>'
    : n[0]==='label' ? `<div class="nav-label">${n[1]}</div>`
    : `<div class="nav-item ${state.page===n[0]?'active':''}" data-nav="${n[0]}" onclick="go('${n[0]}')">${ic(n[2],22)}<span>${n[1]}</span></div>`).join('');
  const bn = [['home','Home','home'],['trending','Trending','flame'],['downloads','Downloads','download'],['history','Library','history']];
  $('#bottomNav').innerHTML = bn.map(([p,l,i])=>
    `<div class="nav-item ${state.page===p?'active':''}" onclick="go('${p}')">${ic(i,22)}<span>${l}</span></div>`).join('');
}
function go(page, opts={}){
  state.page = page;
  if(opts.videoId !== undefined) state.videoId = opts.videoId;
  if(opts.query !== undefined) state.query = opts.query;
  if(opts.category !== undefined) state.category = opts.category;
  render(); window.scrollTo({top:0});
}

/* ================= CARDS ================= */
function cardHTML(v){
  return `<div class="card" onclick="openWatch('${v.id}')">
    <div class="thumb"><img src="${v.th}" loading="lazy" alt="">
      <span class="dur">${v.dur}</span>
      <button class="quick-dl" title="Download" onclick="event.stopPropagation();openModal('${v.id}')">${ic('download',18)}</button>
    </div>
    <div class="card-info">
      <div class="avatar" style="--h:${hue(v.ch)}">${v.ch[0]}</div>
      <div class="meta">
        <div class="card-title">${esc(v.t)}</div>
        <div class="card-sub">${esc(v.ch)} ${v.vf?`<span class="verified">${ic('check',12,true)}</span>`:''}</div>
        <div class="card-sub">${fmtN(v.v)} views · ${v.d}</div>
      </div>
    </div></div>`;
}
function relCardHTML(v){
  return `<div class="rel-card" onclick="openWatch('${v.id}')">
    <div class="rel-thumb"><img src="${v.th}" loading="lazy"><span class="dur">${v.dur}</span></div>
    <div><div class="rel-title">${esc(v.t)}</div>
    <div class="rel-sub">${esc(v.ch)}</div>
    <div class="rel-sub">${fmtN(v.v)} views · ${v.d}</div></div></div>`;
}
function openWatch(id){
  state.history = [id, ...state.history.filter(x=>x!==id)].slice(0,50);
  save('history', state.history);
  go('watch',{videoId:id});
}

/* ================= PAGES ================= */
function filtered(){
  let list = [...VIDEOS];
  if(state.query){
    const q = state.query.toLowerCase();
    list = list.filter(v=> v.t.toLowerCase().includes(q) || v.ch.toLowerCase().includes(q));
  }
  if(state.category==='Trending') list.sort((a,b)=>b.v-a.v);
  else if(state.category!=='All') list = list.filter(v=>v.cat===state.category);
  return list;
}
function chipsHTML(){
  return `<div class="chips">${CATS.map(c=>`<button class="chip ${state.category===c?'active':''}" onclick="go(state.page,{category:'${c}'})">${c}</button>`).join('')}</div>`;
}
function shortsShelf(){
  return `<div class="shelf-title">${ic('playC',24)} Shorts</div>
  <div class="shorts-row">${SHORTS.map(s=>`
    <div class="short-card" onclick="playShort('${s.id}')">
      <div class="short-thumb"><img src="${s.th}" loading="lazy">
        <div class="short-play">${icFill('play',34)}</div></div>
      <div class="short-title">${esc(s.t)}</div>
      <div class="short-views">${fmtN(s.v)} views</div>
    </div>`).join('')}</div>`;
}
function renderHome(){
  let html = chipsHTML();
  if(state.history.length){
    const h = state.history.map(byId).filter(Boolean).slice(0,4);
    html += `<div class="shelf-title">${ic('history',22)} Continue watching</div><div class="grid">${h.map(cardHTML).join('')}</div>`;
  }
  html += shortsShelf();
  html += `<div class="shelf-title">${ic('flame',22)} Recommended for you</div><div class="grid">${filtered().map(cardHTML).join('')}</div>`;
  return html;
}
function renderTrending(){
  const list = [...VIDEOS].sort((a,b)=>b.v-a.v);
  return `<div class="page-title">${ic('flame',26)} Trending now</div>` +
    list.map((v,i)=>`<div class="trend-row" onclick="openWatch('${v.id}')">
      <div class="rank">${i+1}</div>
      <div class="trend-thumb"><img src="${v.th}" loading="lazy"><span class="dur">${v.dur}</span></div>
      <div style="flex:1;min-width:0">
        <div class="card-title" style="font-size:17px">${esc(v.t)}</div>
        <div class="card-sub">${esc(v.ch)} ${v.vf?`<span class="verified">${ic('check',12,true)}</span>`:''}</div>
        <div class="card-sub">${fmtN(v.v)} views · ${v.d}</div>
        <div class="card-sub" style="margin-top:6px">Trending in ${v.cat} · #${i+1} on VidStream</div>
      </div>
      <button class="icon-btn" onclick="event.stopPropagation();openModal('${v.id}')" title="Download">${ic('download',20)}</button>
    </div>`).join('');
}
function renderResults(){
  return `<div class="page-title">${ic('search',24)} Results for “${esc(state.query)}”</div>` +
    (filtered().length ? `<div class="grid">${filtered().map(cardHTML).join('')}</div>`
    : `<div class="empty">${ic('search',56)}<h3>No results found</h3><p>Try a different keyword or channel name.</p></div>`);
}
function renderHistory(){
  const list = state.history.map(byId).filter(Boolean);
  return `<div class="page-title">${ic('history',24)} Watch history</div>` +
    (list.length ? `<div class="grid">${list.map(cardHTML).join('')}</div>`
    : `<div class="empty">${ic('history',56)}<h3>No watch history yet</h3><p>Videos you watch will show up here.</p></div>`);
}
function renderLiked(){
  const list = state.liked.map(byId).filter(Boolean);
  return `<div class="page-title">${ic('heart',24)} Liked videos</div>` +
    (list.length ? `<div class="grid">${list.map(cardHTML).join('')}</div>`
    : `<div class="empty">${ic('heart',56)}<h3>Nothing liked yet</h3><p>Tap the like button on videos to save them here.</p></div>`);
}

/* ---------- DOWNLOADS PAGE ---------- */
function renderDownloads(){
  const dls = state.downloads;
  const active = dls.filter(d=>d.status==='downloading'||d.status==='paused');
  const done = dls.filter(d=>d.status==='done');
  const totalSize = done.reduce((a,d)=>a+d.size,0);
  let html = `<div class="dl-head"><h2>${ic('download',28)} Downloads</h2>
      ${done.length?`<button class="pill" onclick="clearDone()">${ic('trash',16)} Clear completed</button>`:''}</div>
    <div class="dl-stats"><b>${dls.length}</b> items · <b>${fmtSize(totalSize)}</b> saved · <b>${active.filter(d=>d.status==='downloading').length}</b> in progress</div>
    <div class="dl-note">${ic('info',18)} Demo build — uses royalty-free sample videos (Blender Foundation). No copyrighted content is downloaded; progress is simulated locally.</div>`;
  if(!dls.length){
    return html + `<div class="empty">${ic('download',56)}<h3>No downloads yet</h3>
      <p>Tap the download button on any video to save it for offline viewing.</p></div>`;
  }
  const row = d => {
    const v = byId(d.vid) || {th:''};
    const pct = Math.min(100, d.rec/d.size*100);
    const isAud = d.fmt==='audio';
    const actions = d.status==='done'
      ? `<button class="icon-btn go" onclick="openWatch('${d.vid}')" title="Play">${ic('play',18,true)}</button>
         <button class="icon-btn del" onclick="removeDl('${d.id}')" title="Delete">${ic('trash',18)}</button>`
      : d.status==='downloading'
      ? `<button class="icon-btn" onclick="pauseDl('${d.id}')" title="Pause">${ic('pauseC',20)}</button>
         <button class="icon-btn del" onclick="removeDl('${d.id}')" title="Cancel">${ic('close',18)}</button>`
      : `<button class="icon-btn res" onclick="resumeDl('${d.id}')" title="Resume">${ic('playC',20)}</button>
         <button class="icon-btn del" onclick="removeDl('${d.id}')" title="Cancel">${ic('close',18)}</button>`;
    return `<div class="dl-card">
      <div class="dl-thumb"><img src="${v.th}" loading="lazy"><span class="fmt-badge">${isAud?'MP3':d.q}</span></div>
      <div class="dl-body">
        <div class="dl-title">${esc(d.title)}</div>
        <div class="dl-meta">${esc(d.ch)} · ${d.dur} · ${fmtSize(d.rec)} / ${fmtSize(d.size)}
          ${d.status==='downloading'?` · <b style="color:var(--ok)">${d.sp.toFixed(1)} MB/s</b>`:''}
          ${d.status==='paused'?' · <b style="color:var(--warn)">Paused</b>':''}
          ${d.status==='done'?' · <b style="color:var(--ok)">Completed</b>':''}</div>
        <div class="dl-bar"><div class="dl-fill" style="width:${pct}%"></div></div>
        <div class="dl-pct"><span>${pct.toFixed(0)}%</span><span>${isAud?'Audio 128kbps':d.q+' MP4'}</span></div>
      </div>
      <div class="dl-actions">${actions}</div>
    </div>`;
  };
  if(active.length) html += `<div class="dl-section">In progress</div>` + active.map(row).join('');
  if(done.length) html += `<div class="dl-section">Completed</div>` + done.map(row).join('');
  return html;
}
function removeDl(id){ state.downloads = state.downloads.filter(d=>d.id!==id); save('downloads',state.downloads); refreshDlView(); toast('Removed from downloads','trash'); }
function pauseDl(id){ const d = state.downloads.find(d=>d.id===id); if(d){ d.status='paused'; save('downloads',state.downloads); refreshDlView(); } }
function resumeDl(id){ const d = state.downloads.find(d=>d.id===id); if(d){ d.status='downloading'; d.sp=1.2+Math.random()*5; save('downloads',state.downloads); startEngine(); refreshDlView(); } }
function clearDone(){ state.downloads = state.downloads.filter(d=>d.status!=='done'); save('downloads',state.downloads); refreshDlView(); toast('Completed downloads cleared','trash'); }
function refreshDlView(){ if(state.page==='downloads') render(); renderNav(); }
function startEngine(){
  if(engine) return;
  engine = setInterval(()=>{
    let any = false;
    state.downloads.forEach(d=>{
      if(d.status!=='downloading') return;
      any = true;
      d.rec += d.sp * (0.6 + Math.random()*0.9);
      if(d.rec >= d.size){ d.rec=d.size; d.status='done'; toast(`Downloaded: ${d.title.slice(0,32)}…`,'check',true); }
    });
    save('downloads', state.downloads);
    if(!any){ clearInterval(engine); engine=null; }
    if(state.page==='downloads') render();
  }, 1000);
}
  /* ---------- WATCH PAGE ---------- */
function commentsFor(id){
  const seed = [...id].reduce((a,c)=>a+c.charCodeAt(0),0);
  const n = 4 + seed % 3;
  const list = [];
  for(let i=0;i<n;i++){
    const p = COMMENT_POOL[(seed+i*5)%COMMENT_POOL.length];
    const ch = VIDEOS[(seed+i)%VIDEOS.length].ch;
    list.push({user:ch, text:p, when:`${1+((seed+i)%13)} ${['hours','days','weeks'][i%3]} ago`, likes:(seed*i*137)%4200, key:id+':'+i});
  }
  const mine = (state.comments[id]||[]).map((c,i)=>({user:'You',text:c.text,when:'just now',likes:0,key:id+':me'+i}));
  return [...mine,...list];
}
function renderWatch(){
  const v = byId(state.videoId);
  if(!v) return renderHome();
  const liked = state.liked.includes(v.id);
  const subbed = state.subs.includes(v.ch);
  const rel = VIDEOS.filter(x=>x.id!==v.id).slice(0,10);
  const comments = commentsFor(v.id);
  return `<div class="watch">
    <div>
      <div class="player" id="player">
        <video id="video" src="${v.src}" poster="${v.th}" playsinline></video>
        <div class="big-play" id="bigPlay"><span>${icFill('play',34)}</span></div>
        <div class="p-controls" id="pControls">
          <div class="p-progress" id="pProgress"><div class="p-buffered" id="pBuffered"></div><div class="p-played" id="pPlayed"></div></div>
          <div class="p-row">
            <button class="p-btn" id="btnPlay">${icFill('play',22)}</button>
            <button class="p-btn" id="btnMute">${ic('vol',20)}</button>
            <div class="vol open" id="volWrap"><input type="range" id="vol" min="0" max="1" step="0.05" value="1"></div>
            <span class="p-time" id="pTime">0:00 / ${v.dur}</span>
            <div class="p-spacer"></div>
            <button class="p-btn" id="btnSpeed">${ic('gear',20)}</button>
            <button class="p-btn" id="btnFull">${ic('full',20)}</button>
          </div>
          <div class="speed-menu" id="speedMenu">
            ${[0.5,0.75,1,1.25,1.5,2].map(s=>`<button data-sp="${s}" class="${s===1?'on':''}">${s}x</button>`).join('')}
          </div>
        </div>
      </div>
      <h1 class="w-title">${esc(v.t)}</h1>
      <div class="w-actions">
        <div class="w-channel">
          <div class="avatar" style="--h:${hue(v.ch)}">${v.ch[0]}</div>
          <div><div class="w-cname">${esc(v.ch)} ${v.vf?`<span class="verified">${ic('check',13,true)}</span>`:''}</div>
          <div class="w-csubs">${fmtN(v.v/28)} subscribers</div></div>
        </div>
        <button class="pill ${subbed?'subscribed':''}" onclick="toggleSub('${esc(v.ch).replace(/'/g,"\\'")}')">
          ${subbed?ic('check',17):ic('heart',17)} ${subbed?'Subscribed':'Subscribe'}</button>
        <button class="pill ${liked?'liked':''}" onclick="toggleLike('${v.id}')">${ic('like',17)} ${fmtN(Math.round(v.v/22)+(liked?1:0))}</button>
        <button class="pill" onclick="shareVideo('${v.id}')">${ic('share',17)} Share</button>
        <button class="pill dl" onclick="openModal('${v.id}')">${ic('download',17)} Download</button>
      </div>
      <div class="w-desc" id="desc" onclick="this.classList.toggle('open')">
        <div class="d-meta">${fmtN(v.v)} views · ${v.d} · #${v.cat} #vidstream</div>
        <p>${esc(v.t)} — presented by ${esc(v.ch)}. Royalty-free sample footage courtesy of the Blender Foundation open movie project.
        Watch in up to 1080p, download for offline playback in MP4 or MP3, and adjust playback speed.</p>
        <span class="more">Show more</span>
      </div>
      <div class="c-title">${comments.length} Comments</div>
      <div class="c-add">
        <div class="avatar-me" style="width:38px;height:38px">V</div>
        <input id="cInput" placeholder="Add a comment…" onkeydown="if(event.key==='Enter')postComment('${v.id}')">
        <button class="c-send" onclick="postComment('${v.id}')">Comment</button>
      </div>
      <div id="cList">${comments.map(c=>commentHTML(c)).join('')}</div>
    </div>
    <div>
      <div class="rel-head"><div class="shelf-title" style="margin:0 0 12px">${ic('film',20)} Up next</div>
        <button class="pill" style="font-size:12px;padding:7px 13px">Autoplay</button></div>
      ${rel.map(relCardHTML).join('')}
    </div>
  </div>`;
}
function commentHTML(c){
  const on = state.cLikes.includes(c.key);
  return `<div class="comment">
    <div class="avatar" style="--h:${hue(c.user)};width:36px;height:36px;font-size:15px">${c.user==='You'?'V':c.user[0]}</div>
    <div style="min-width:0;flex:1">
      <div class="c-head">@${esc(c.user.toLowerCase().replace(/\s/g,''))}<span>${c.when}</span></div>
      <div class="c-text">${esc(c.text)}</div>
      <div class="c-like ${on?'on':''}" onclick="likeComment('${c.key}',this)">${ic('like',15)} <span>${fmtN(c.likes+(on?1:0))}</span></div>
    </div></div>`;
}
function likeComment(key, el){
  const i = state.cLikes.indexOf(key);
  if(i>=0) state.cLikes.splice(i,1); else state.cLikes.push(key);
  save('cLikes', state.cLikes);
  const span = el.querySelector('span');
  let n = parseInt(span.textContent.replace(/[KM]/g, m=>m==='K'?'000':'00000'))||0;
  span.textContent = fmtN(Math.max(0,n+(i>=0?-1:1)));
  el.classList.toggle('on');
}
function postComment(id){
  const inp = $('#cInput');
  const text = inp.value.trim();
  if(!text) return;
  state.comments[id] = [{text, at:Date.now()}, ...(state.comments[id]||[])];
  save('comments', state.comments);
  inp.value='';
  $('#cList').insertAdjacentHTML('afterbegin', commentHTML({user:'You',text,when:'just now',likes:0,key:id+':me0'}));
  toast('Comment posted','check',true);
}
function toggleSub(ch){
  const i = state.subs.indexOf(ch);
  if(i>=0){ state.subs.splice(i,1); toast('Unsubscribed from '+ch,'close'); }
  else { state.subs.push(ch); toast('Subscribed to '+ch+' 🔔','check',true); }
  save('subs', state.subs); render();
}
function toggleLike(id){
  const i = state.liked.indexOf(id);
  if(i>=0){ state.liked.splice(i,1); toast('Removed from liked videos','heart'); }
  else { state.liked.push(id); toast('Added to liked videos','heart',true); }
  save('liked', state.liked); render();
}
function shareVideo(id){
  const url = location.href.split('#')[0] + '#watch=' + id;
  (navigator.clipboard?.writeText(url) || Promise.reject()).then(
    ()=>toast('Link copied to clipboard','share',true),
    ()=>toast('Share link ready','share'));
}

/* ---------- VIDEO PLAYER ---------- */
let hideTimer=null, seeking=false;
function setupPlayer(){
  const video = $('#video'); if(!video) return;
  const bigPlay=$('#bigPlay'), ctrls=$('#pControls'), bar=$('#pProgress'),
        played=$('#pPlayed'), buffered=$('#pBuffered'), timeEl=$('#pTime'),
        btnPlay=$('#btnPlay'), btnMute=$('#btnMute'), vol=$('#vol'), volWrap=$('#volWrap'),
        btnFull=$('#btnFull'), btnSpeed=$('#btnSpeed'), speedMenu=$('#speedMenu'), player=$('#player');

  const showPlay = ()=>{ bigPlay.classList.remove('hide'); btnPlay.innerHTML=icFill('play',22); };
  const showPause = ()=>{ bigPlay.classList.add('hide'); btnPlay.innerHTML=icFill('pause',22); };
  const toggle = ()=> video.paused ? video.play() : video.pause();
  bigPlay.onclick = toggle;
  video.onclick = toggle;
  btnPlay.onclick = toggle;
  video.addEventListener('play', showPause);
  video.addEventListener('pause', showPlay);

  video.addEventListener('timeupdate', ()=>{
    if(video.duration){ played.style.width = (video.currentTime/video.duration*100)+'%';
      timeEl.textContent = fmtTime(video.currentTime)+' / '+fmtTime(video.duration); }
  });
  video.addEventListener('progress', ()=>{
    try{ if(video.buffered.length && video.duration)
      buffered.style.width = (video.buffered.end(video.buffered.length-1)/video.duration*100)+'%'; }catch{}
  });
  const seekAt = e => { const r=bar.getBoundingClientRect();
    const p = Math.min(1,Math.max(0,(e.clientX-r.left)/r.width));
    if(video.duration) video.currentTime = p*video.duration; };
  bar.addEventListener('pointerdown', e=>{ seeking=true; bar.setPointerCapture(e.pointerId); seekAt(e); });
  bar.addEventListener('pointermove', e=>{ if(seeking) seekAt(e); });
  bar.addEventListener('pointerup', ()=> seeking=false);

  const volIcon = ()=> btnMute.innerHTML = (video.muted||video.volume===0) ? ic('mute',20) : ic('vol',20);
  btnMute.onclick = ()=>{ video.muted=!video.muted; volIcon(); };
  vol.oninput = ()=>{ video.volume=+vol.value; video.muted=vol.value==0; volIcon(); };
  volWrap.parentElement.addEventListener('mouseenter', ()=>volWrap.classList.add('open'));
  volWrap.parentElement.addEventListener('mouseleave', ()=>volWrap.classList.remove('open'));

  btnFull.onclick = ()=>{ document.fullscreenElement ? document.exitFullscreen() : player.requestFullscreen?.(); };
  btnSpeed.onclick = e=>{ e.stopPropagation(); speedMenu.classList.toggle('open'); };
  speedMenu.querySelectorAll('button').forEach(b=> b.onclick = ()=>{
    video.playbackRate = +b.dataset.sp;
    speedMenu.querySelectorAll('button').forEach(x=>x.classList.toggle('on', x===b));
    speedMenu.classList.remove('open');
    toast('Playback speed: '+b.dataset.sp+'x','gear');
  });
  document.addEventListener('click', e=>{ if(!speedMenu.contains(e.target) && e.target!==btnSpeed) speedMenu.classList.remove('open'); });

  const poke = ()=>{ ctrls.classList.remove('hide'); clearTimeout(hideTimer);
    hideTimer = setTimeout(()=>{ if(!video.paused && !speedMenu.classList.contains('open')) ctrls.classList.add('hide'); }, 2600); };
  player.addEventListener('mousemove', poke);
  player.addEventListener('mouseleave', ()=>{ if(!video.paused) ctrls.classList.add('hide'); });
  video.addEventListener('play', poke);
  video.addEventListener('ended', ()=>{ showPlay(); ctrls.classList.remove('hide'); });
  volIcon();
}

/* ---------- SHORTS ---------- */
function playShort(id){
  const s = SHORTS.find(x=>x.id===id);
  const v = { ...byId('v11'), id:'short_'+s.id, t:s.t, ch:s.ch, v:s.v, src:s.src, th:s.th, dur:'0:15', vf:0 };
  VIDEOS.push(v);
  openWatch('short_'+s.id);
}

/* ---------- DOWNLOAD MODAL ---------- */
function estSize(dur, fmt, q){
  const sec = parseDur(dur);
  if(fmt==='audio') return sec * (q==='320 kbps' ? 0.04 : 0.016);
  const mbps = {'1080p':5,'720p':2.5,'480p':1.2,'360p':0.7}[q];
  return Math.max(2, sec * mbps * 0.125);
}
function openModal(vid){
  modalVideo = byId(vid); dlTab='video';
  drawModal();
  $('#modalOv').classList.add('show');
}
function drawModal(){
  const v = modalVideo; if(!v) return;
  const vidQ = [['1080p','Full HD'],['720p','HD'],['480p',''],['360p','']];
  const audQ = [['320 kbps','Best'],['128 kbps','']];
  const qs = dlTab==='video' ? vidQ : audQ;
  $('#modalBox').innerHTML = `
    <div class="m-head">
      <img src="${v.th}" alt="">
      <div><h3>${esc(v.t)}</h3><p>${esc(v.ch)} · ${v.dur} · ${fmtN(v.v)} views</p></div>
      <button class="icon-btn m-close" onclick="closeModal()">${ic('close',20)}</button>
    </div>
    <div class="m-tabs">
      <button class="m-tab ${dlTab==='video'?'active':''}" onclick="dlTab='video';drawModal()">${ic('film',17)} Video MP4</button>
      <button class="m-tab ${dlTab==='audio'?'active':''}" onclick="dlTab='audio';drawModal()">${ic('music',17)} Audio MP3</button>
    </div>
    <div class="m-list">
      ${qs.map(([q,note])=>{
        const size = estSize(v.dur, dlTab, q);
        const did = `d_${v.id}_${dlTab}_${q}`;
        const exists = state.downloads.find(d=>d.id===did);
        return `<div class="m-row">
          <div><span class="m-q">${q}</span>${note?`<span class="m-note">${note}</span>`:''}
            <div class="m-size">${fmtSize(size)} · ${dlTab==='video'?'MP4 · H.264':'MP3 · Audio only'}</div></div>
          <button class="m-dl" onclick="startDownload('${did}','${v.id}','${dlTab}','${q}',${size})">
            ${exists&&exists.status==='done'?ic('check',20):ic('download',20)}</button>
        </div>`; }).join('')}
    </div>`;
}
function startDownload(did, vid, fmt, q, size){
  const exists = state.downloads.find(d=>d.id===did);
  if(exists && exists.status==='done'){ toast('Already downloaded ✔','check',true); return; }
  if(exists && exists.status!=='done'){ toast('Already in download queue','info'); return; }
  const v = byId(vid);
  state.downloads.unshift({ id:did, vid, title:v.t, ch:v.ch, dur:v.dur, fmt, q,
    size, rec:0, sp:1.2+Math.random()*5, status:'downloading', at:Date.now() });
  save('downloads', state.downloads);
  startEngine();
  closeModal();
  toast(`Downloading “${v.t.slice(0,28)}…” (${q})`,'download');
  renderNav();
  if(state.page==='downloads') render();
}
function closeModal(){ $('#modalOv').classList.remove('show'); modalVideo=null; }
 $('#modalOv').addEventListener('click', e=>{ if(e.target.id==='modalOv') closeModal(); });

/* ---------- SEARCH ---------- */
const sInput = $('#searchInput'), sSuggest = $('#suggest');
function doSearch(){
  const q = sInput.value.trim();
  sSuggest.classList.remove('open');
  if(!q) return;
  go('results',{query:q});
}
sInput.addEventListener('input', ()=>{
  const q = sInput.value.trim().toLowerCase();
  if(!q){ sSuggest.classList.remove('open'); return; }
  const hits = [...VIDEOS.filter(v=>v.t.toLowerCase().includes(q)||v.ch.toLowerCase().includes(q)).slice(0,6),
                ...SHORTS.filter(s=>s.t.toLowerCase().includes(q)).slice(0,2)];
  sSuggest.innerHTML = hits.length
    ? hits.map(h=>`<div onclick="sInput.value='${esc(h.t).replace(/'/g,"\\'")}';doSearch()">${ic('search',16)}<span>${esc(h.t)}</span></div>`).join('')
    : `<div>${ic('search',16)}<span>Search “${esc(q)}”</span></div>`;
  sSuggest.classList.add('open');
});
sInput.addEventListener('keydown', e=>{ if(e.key==='Enter') doSearch(); });
document.addEventListener('click', e=>{ if(!e.target.closest('.search-wrap')) sSuggest.classList.remove('open'); });
 $('#searchBtn').onclick = doSearch;
document.addEventListener('keydown', e=>{
  if(e.key==='/' && document.activeElement!==sInput){ e.preventDefault(); sInput.focus(); }
  if(e.key==='Escape'){ closeModal(); sSuggest.classList.remove('open'); }
});

/* ---------- THEME / HEADER ---------- */
function applyTheme(){
  document.body.classList.toggle('light', state.theme==='light');
  $('#themeBtn').innerHTML = ic(state.theme==='light'?'moon':'sun',20);
  $('#logoMark').innerHTML = icFill('play',16);
  $('#hamburger').innerHTML = ic('menu',22);
  $('#searchBtn').innerHTML = ic('search',19);
}
 $('#themeBtn').onclick = ()=>{ state.theme = state.theme==='dark'?'light':'dark'; save('theme',state.theme); applyTheme(); };
 $('#hamburger').onclick = ()=>{ $('#sidebar').classList.toggle('open'); $('#overlay').classList.toggle('show'); };
 $('#overlay').onclick = ()=>{ $('#sidebar').classList.remove('open'); $('#overlay').classList.remove('show'); };

/* ---------- RENDER ROOT ---------- */
function render(){
  const pages = { home:renderHome, trending:renderTrending, results:renderResults,
    downloads:renderDownloads, history:renderHistory, liked:renderLiked, watch:renderWatch };
  $('#main').innerHTML = (pages[state.page]||renderHome)();
  if(state.page==='watch') setupPlayer();
  renderNav();
}
applyTheme();
render();
