# VidStream

Modularized from the supplied VidStream homepage without redesigning the existing UI.

- `homepage.html` — page markup
- `css/main.css` — existing inline CSS
- `js/app.js` — existing inline JavaScript
- `index.html` — entry point that opens `homepage.html`
- `assets/` — reserved for images/icons

Upload the whole `VidStream_Modular.zip` project to GitHub.
